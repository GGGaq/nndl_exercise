# numpy exercise




## 数据集: 无



## 题目要求： 

​		按照ipython 文件中的 要求，利用numpy 实现对应的操作。